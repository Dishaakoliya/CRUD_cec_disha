import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class bookdisplay
 */
@WebServlet("/bookdisplay")
public class bookdisplay extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public bookdisplay() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

		PrintWriter out=response.getWriter();
		
		String name=request.getParameter("name");
		String price=request.getParameter("price");
		String author=request.getParameter("author");
		
		try {
			Class.forName("com.mysql.jdbc.Driver");
			Connection con=DriverManager.getConnection("jdbc:mysql://128.66.203.247:3306/imsc7it105","imsc7it105","sumo@123");
			String display="select * from books";
			PreparedStatement ps=con.prepareStatement(display);
			
			ResultSet rs=ps.executeQuery();
			
			while(rs.next())
			{
				String id=rs.getString(1);
			    name=rs.getString(2);
			    price=rs.getString(3);
			    author=rs.getString(4);
			    
			    String LinkUrl="cdisplay?id="+id+"&name="+name+"&price="+price+"&author="+author;
			    
			    		
			    out.print("<html>");
			    out.print("<body>");
			    out.print("<a href='"+LinkUrl+"'>"+name+"</a>");
			    
			    out.print("</body>");
			    out.print("</html>");
			    
			}
			
		}
		catch(Exception e)
		{
			System.out.println(e);
		}
		
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}