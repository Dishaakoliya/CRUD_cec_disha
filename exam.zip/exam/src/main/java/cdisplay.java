import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class cdisplay
 */
@WebServlet("/cdisplay")
public class cdisplay extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public cdisplay() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		response.setContentType("text/html");
        PrintWriter out=response.getWriter();
		
        String id=request.getParameter("id");
		String name=request.getParameter("name");
		String price=request.getParameter("price");
		String author=request.getParameter("author");
		
		String editUrl="edit?name="+name+"&price="+price+"&author="+author+"&id="+id;
		
		
		   out.println("<html>");
		   out.println("<body>");
		   out.println("<br>name is:"+name);
		   out.println("<br>price is:"+price);
		   out.println("<br>author is:"+author);
		   out.println("<br><br><a href='"+editUrl+"'>edit book</a>");
		   
		   out.println("</body>");
		   out.println("</html>");
	}
}