import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class edit
 */
@WebServlet("/edit")
public class edit extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public edit() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */

		
		
	
	protected void doGet(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException {

		// TODO Auto-generated method stub
		res.setContentType("text/html");
		PrintWriter out= res.getWriter();
		out.println("Edit Book");
		String id = req.getParameter("id");
		String name=req.getParameter("name");
		String price=req.getParameter("price");
		String author=req.getParameter("author");

        out.println(name);
        out.println("<form action='editpage' method='POST'>");
        out.print("<table>");  
        out.print("<tr><td></td><td><input type='hidden' name='id' value='"+id+"'/></td></tr>");  
        out.print("<tr><td>Book Name:</td><td><input type='text' name='bname' value='"+name+"'/></td></tr>");  
        out.print("<tr><td>Price:</td><td><input type='text' name='bprice' value='"+price+"'/></td></tr>"); 
        out.print("<tr><td>Price:</td><td><input type='text' name='bprice' value='"+author+"'/></td></tr>"); 

        out.println("<tr><td></td><td><input type='submit'value='EditBook'></td>");
        out.println("</table></form>");
        
        
        
	}
	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}